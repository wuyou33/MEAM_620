Up-to-date manual is available at https://sites.google.com/site/kmelquad/
Please read the license file KMEL_LICENSE.pdf before using this software

