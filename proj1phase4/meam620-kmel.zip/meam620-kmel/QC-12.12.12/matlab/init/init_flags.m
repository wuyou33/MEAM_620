%Copyright KMel Robotics 2012. Must read KMEL_LICENSE.pdf for terms and conditions before use.
%init flags
control_on = 1; %run the controllers
vicon_on = 1; %use vicon system
sim_on = 0; %turn the simulation on
use_ipc = 1; %use ipc
get_feedback = 0; %get feedback from the quad
debugon = 0; %print some debug` messages
quadcmdtype = 1; %type 1 is just trpy, type 3 has drpy and onboard gains