%Copyright KMel Robotics 2012. Must read KMEL_LICENSE.pdf for terms and conditions before use.
function result = ipcAPIFlushLocalQueue

result = ipcAPI('flush_local_queue');
