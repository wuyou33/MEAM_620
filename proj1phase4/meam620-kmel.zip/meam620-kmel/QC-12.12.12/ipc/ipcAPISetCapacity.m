%Copyright KMel Robotics 2012. Must read KMEL_LICENSE.pdf for terms and conditions before use.
function result = ipcAPISetCapacity(capacity);

result = ipcAPI('set_capacity',capacity);
