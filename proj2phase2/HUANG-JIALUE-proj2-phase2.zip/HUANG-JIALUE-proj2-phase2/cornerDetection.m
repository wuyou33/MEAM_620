function [ features, points ] = cornerDetection( I )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
    pts = detectSURFFeatures(I);
    [features, points] = extractFeatures(I, pts);
end
