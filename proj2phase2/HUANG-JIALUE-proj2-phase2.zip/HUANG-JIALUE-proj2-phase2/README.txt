1. Please add studentdata1.m file before running.
2. Main program is in run.m file.
3. run.m file uses MATLAB built-in function 'detectSURFFeature', so please make sure your MATLAB is 2012a or later version.