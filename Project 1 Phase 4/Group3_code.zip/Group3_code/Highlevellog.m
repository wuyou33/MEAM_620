% High-level log saves

save ViconData.mat ViconData
save VelSave.mat VelSave
save trpySave.mat trpySave
save DesPosSave.mat DesPosSave
save DesEulSave.mat DesEulSave